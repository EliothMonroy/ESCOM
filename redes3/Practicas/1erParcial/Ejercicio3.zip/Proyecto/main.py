from gestor import Gestor

gestor=Gestor()